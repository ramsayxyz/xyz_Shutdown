xyz_Shutdown — Windows Installer
================================

Thank you for downloading xyz_Shutdown!

📦 How to Install:
-------------------
1. Double-click the file named:
   MyAppInstaller.exe

2. Follow the on-screen setup instructions.

3. The app will be installed to:
   C:\Program Files\Shutdownxyz

4. A shortcut will be added to your Start Menu and Desktop.

🖥️ What is this?
------------------
xyz_Shutdown is a utility application for shutting down your system quickly and safely.

📋 License:
------------
This app is provided under the MIT License. You can view the license terms in the LICENSE file.

❓ Need help?
-------------
If you encounter issues or have questions, please visit the GitHub page or contact the developer.
